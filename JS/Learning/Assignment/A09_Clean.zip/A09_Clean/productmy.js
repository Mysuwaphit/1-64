import { products } from "./ProductList.mjs";

export function addNewProduct(products) {

    const product = document.createElement("div") //create element div by assign to product
    product.setAttribute("class", "product") //set attribute class product in varriable product
    const image = document.createElement("img") //create element img by assign to image
    image.setAttribute("src", products.img); //set attribute src that is img in each product
    const name = document.createElement("div") //create element div by assign to name
    name.setAttribute("id", "name") //set attribute id that is price
    name.innerHTML = products.productName; //set value in tag div by productName
    const pricePD = document.createElement("div") //create element div by assign to pricePD
    pricePD.setAttribute("id", "price") //set attribute id that is price
    pricePD.innerHTML = `${products.price}$`; //set value in tag div by price 
    const id = document.createElement('div')
    id.setAttribute('id','id')
    const innerId = document.createElement('p');
    innerId.setAttribute('id','idPd');
    innerId.setAttribute('style','opacity: 0.0')
    innerId.innerHTML = products.productId;


    const button = document.createElement("button"); //create element button by assign to variable button
    button.setAttribute("class", "button") //set attribute class is button
    button.innerHTML = `<i class="fa fa-shopping-cart" aria-hidden="true"></i> ADD TO CART` //assign value <i...> in button by innerHTML

    id.append(image, name, pricePD, button, innerId); //merge element from image,name,pricePD,button to be child the product 
    product.append(id);
    return product;

}

function addPd(n) { //add each product
    n.forEach((n) => {  //loop addNewProduct in each product
        let product = addNewProduct(n);
        displayPd(product);
    }
    );
}

// search button
addPd(products);

function displayPd(m) { // display the products
    let productsList = document.querySelector("#products") // get tag that has class name products
    productsList.append(m);  //and then merge product from function to be child in tag div calss products
}

let click = false;
function toggleSearch() {  //Show and hidden search panel 
    let inputName = document.querySelector("#input");

    click = !click;
    if (click) {
        inputName.setAttribute('class', 'visible');//Press to display the search panel.

    } else {
        inputName.setAttribute('class', 'invisible');//Press to hide search panel.
    }
}

let search = document.querySelector("#search");
search.setAttribute('style', 'padding-top: 15px');
search.addEventListener('click', toggleSearch); //If click the magnifying glass code will calling toggleSearch function

const searching = () => {
    let input, filter, div, div2, pdName, txtValue, i;
    input = document.querySelector("#inputValue");
    filter = input.value.toUpperCase(); // Assign value from tag input to filter in uppercase 
    div = document.getElementById("products"); // Select all products and put them in the div
    div2 = div.getElementsByClassName("product"); // Select product and put them in the div2

    for (i = 0; i < products.length; i++) {
        pdName = div2[i].getElementsByTagName("div")[0];
        txtValue = pdName.textContent || pdName.innerText; // assign value in first tag div that the name of product to txtValue
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            div2[i].style.display = ""; // Bring the product that include the condition to show while sreaching
        } else {
            div2[i].style.display = "none"; // Hidden the product that is't include the condition while sreaching
        }
    }
}

let btn = document.querySelector("#searchBtn");
btn.onclick = searching; // Add event onclick to search button for searching
